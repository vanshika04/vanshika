A Pen created at CodePen.io. You can find this one at http://codepen.io/rahulkapoor/pen/tkLjK.

 updated , the disqus that was recently changed on disqus official site , love to all.